package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class Customizedprogram extends AppCompatActivity {

    private TextView programTextView;
    private ImageView ivBackCustomProgram;
    private MaterialButton btnLogoutProgram;

    // SharedPreferences File Names (Standardized)
    private static final String SHARED_PREF_NAME = "dietAppPrefs"; // For login status
    public static final String KEY_LOGGED_IN_USER_EMAIL = "logged_in_user_email";

    // SharedPreferences File Names for reading various preferences
    private static final String GOAL_PREFS_NAME = "GoalPrefs";
    private static final String INTOLERANCE_PREFS_NAME = "IntolerancePrefs";
    private static final String FOOD_PREFS_NAME = "FoodPrefs";
    private static final String MEAT_PREFS_NAME = "MeatPrefs";
    private static final String HEALTH_PREFS_NAME = "HealthPrefs";
    private static final String MED_PREFS_NAME = "MedPrefs";
    private static final String ACTIVITY_PREFS_NAME = "ActivityPrefs";

    // --- KEYS (Ensure these match exactly what's saved in each respective Activity) ---

    // Keys from GoalSelectionActivity.java
    public static final String KEY_GOAL_LOSE_WEIGHT = "goal_lose_weight";
    public static final String KEY_GOAL_MANAGE_CONDITION = "goal_manage_condition";
    public static final String KEY_GOAL_INCREASE_ENERGY = "goal_increase_energy";
    public static final String KEY_GOAL_HEALTHY_LIFESTYLE = "goal_healthy_lifestyle";

    // Keys from Intolerence.java
    private static final String KEY_INT_GLUTEN = "gluten";
    private static final String KEY_INT_LACTOSE = "lactose";
    private static final String KEY_INT_NUTS = "nuts";
    private static final String KEY_INT_SOY = "soy";
    private static final String KEY_INT_EGGS = "eggs";
    private static final String KEY_INT_SHELLFISH = "shellfish";
    private static final String KEY_INT_FISH_INTOLERANCE = "fish_intolerance";
    private static final String KEY_INT_SESAME = "sesame";
    private static final String KEY_INT_MUSTARD = "mustard";
    private static final String KEY_INT_CUSTOM = "custom_intolerance";

    // Keys from Foodpreferences.java
    private static final String KEY_FOOD_VEGETARIAN = "vegetarian";
    private static final String KEY_FOOD_NON_VEGETARIAN = "nonVegetarian";
    private static final String KEY_FOOD_VEGAN = "vegan";
    private static final String KEY_FOOD_EGGETARIAN = "eggetarian";
    private static final String KEY_FOOD_PESCATARIAN = "pescatarian";
    private static final String KEY_FOOD_CUSTOM = "customFood";

    // Keys from Meatpreferences.java
    private static final String KEY_MEAT_CHICKEN = "chicken";
    private static final String KEY_MEAT_FISH = "fish_meat";
    private static final String KEY_MEAT_BEEF = "beef";
    private static final String KEY_MEAT_LAMB = "lamb";
    private static final String KEY_MEAT_PORK = "pork";
    private static final String KEY_MEAT_TURKEY = "turkey";
    private static final String KEY_MEAT_DUCK = "duck";
    private static final String KEY_MEAT_CUSTOM = "custom_meat";

    // Keys from Diseases.java (HealthPrefs)
    private static final String KEY_HEALTH_DIABETES = "diabetes";
    private static final String KEY_HEALTH_HYPERTENSION = "hypertension";
    private static final String KEY_HEALTH_THYROID = "thyroid";
    private static final String KEY_HEALTH_HEART_DISEASE = "heart_disease";
    private static final String KEY_HEALTH_KIDNEY_ISSUES = "kidney_issues";
    private static final String KEY_HEALTH_GUT_ISSUES = "gut_issues";
    private static final String KEY_HEALTH_PCOS = "pcos";
    private static final String KEY_HEALTH_CUSTOM_CONDITION = "custom_condition";

    // Keys from Medications.java (MedPrefs)
    private static final String KEY_MED_VITAMINS = "vitamins";
    private static final String KEY_MED_HORMONES = "hormones";
    private static final String KEY_MED_ANTIBIOTICS = "antibiotics";
    private static final String KEY_MED_ANXIETY_MEDS = "anxiety_meds";
    private static final String KEY_MED_NONE = "none";
    private static final String KEY_MED_OTHER_MEDICATION = "other_medication";

    // Keys from Physicalactivities.java (ActivityPrefs)
    private static final String KEY_ACTIVITY_WALKING = "walking";
    private static final String KEY_ACTIVITY_RUNNING = "running";
    private static final String KEY_ACTIVITY_CYCLING = "cycling";
    private static final String KEY_ACTIVITY_SWIMMING = "swimming";
    private static final String KEY_ACTIVITY_GYM = "gym";
    private static final String KEY_ACTIVITY_YOGA = "yoga";
    private static final String KEY_ACTIVITY_SPORTS = "sports";
    private static final String KEY_ACTIVITY_CUSTOM = "custom_activity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customizedprogram);

        programTextView = findViewById(R.id.programTextView);
        ivBackCustomProgram = findViewById(R.id.iv_back_custom_program);
        btnLogoutProgram = findViewById(R.id.btn_logout_program);

        String programHtml = generateCustomizedProgram();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            programTextView.setText(Html.fromHtml(programHtml, Html.FROM_HTML_MODE_LEGACY));
        } else {
            programTextView.setText(Html.fromHtml(programHtml));
        }

        if (ivBackCustomProgram != null) {
            ivBackCustomProgram.setOnClickListener(v -> {
                Intent intent = new Intent(Customizedprogram.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (btnLogoutProgram != null) {
            btnLogoutProgram.setOnClickListener(v -> performLogout());
        }
    }

    private void performLogout() {
        SharedPreferences prefs = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_LOGGED_IN_USER_EMAIL);
        editor.apply();

        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(Customizedprogram.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private String generateCustomizedProgram() {
        SharedPreferences goalPrefs = getSharedPreferences(GOAL_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences intolerancePrefs = getSharedPreferences(INTOLERANCE_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences foodPrefs = getSharedPreferences(FOOD_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences meatPrefs = getSharedPreferences(MEAT_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences healthPrefs = getSharedPreferences(HEALTH_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences medPrefs = getSharedPreferences(MED_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences activityPrefs = getSharedPreferences(ACTIVITY_PREFS_NAME, MODE_PRIVATE);

        boolean wantsToLoseWeight = goalPrefs.getBoolean(KEY_GOAL_LOSE_WEIGHT, false);
        boolean wantsToManageCondition = goalPrefs.getBoolean(KEY_GOAL_MANAGE_CONDITION, false);
        boolean wantsToIncreaseEnergy = goalPrefs.getBoolean(KEY_GOAL_INCREASE_ENERGY, false);
        boolean wantsHealthyLifestyle = goalPrefs.getBoolean(KEY_GOAL_HEALTHY_LIFESTYLE, false);
        if (!wantsToLoseWeight && !wantsToManageCondition && !wantsToIncreaseEnergy && !wantsHealthyLifestyle) {
            wantsHealthyLifestyle = true;
        }

        boolean isGlutenIntolerant = intolerancePrefs.getBoolean(KEY_INT_GLUTEN, false);
        boolean isLactoseIntolerant = intolerancePrefs.getBoolean(KEY_INT_LACTOSE, false);
        boolean hasNutAllergy = intolerancePrefs.getBoolean(KEY_INT_NUTS, false);
        boolean isSoyIntolerant = intolerancePrefs.getBoolean(KEY_INT_SOY, false);
        boolean hasEggAllergy = intolerancePrefs.getBoolean(KEY_INT_EGGS, false);
        boolean hasShellfishAllergy = intolerancePrefs.getBoolean(KEY_INT_SHELLFISH, false);
        boolean hasFishIntolerance = intolerancePrefs.getBoolean(KEY_INT_FISH_INTOLERANCE, false);
        boolean isSesameIntolerant = intolerancePrefs.getBoolean(KEY_INT_SESAME, false);
        boolean isMustardIntolerant = intolerancePrefs.getBoolean(KEY_INT_MUSTARD, false);
        String customIntolerance = intolerancePrefs.getString(KEY_INT_CUSTOM, "");

        boolean isVegan = foodPrefs.getBoolean(KEY_FOOD_VEGAN, false);
        boolean isVegetarian = foodPrefs.getBoolean(KEY_FOOD_VEGETARIAN, false);
        boolean isNonVegetarian = foodPrefs.getBoolean(KEY_FOOD_NON_VEGETARIAN, false);
        boolean isEggetarian = foodPrefs.getBoolean(KEY_FOOD_EGGETARIAN, false);
        boolean isPescatarian = foodPrefs.getBoolean(KEY_FOOD_PESCATARIAN, false);
        String customFoodPreference = foodPrefs.getString(KEY_FOOD_CUSTOM, "");

        boolean prefersChicken = meatPrefs.getBoolean(KEY_MEAT_CHICKEN, false);
        boolean prefersFishMeat = meatPrefs.getBoolean(KEY_MEAT_FISH, false);
        boolean prefersBeef = meatPrefs.getBoolean(KEY_MEAT_BEEF, false);
        boolean prefersLamb = meatPrefs.getBoolean(KEY_MEAT_LAMB, false);
        boolean prefersPork = meatPrefs.getBoolean(KEY_MEAT_PORK, false);
        boolean prefersTurkey = meatPrefs.getBoolean(KEY_MEAT_TURKEY, false);
        boolean prefersDuck = meatPrefs.getBoolean(KEY_MEAT_DUCK, false);
        String customMeat = meatPrefs.getString(KEY_MEAT_CUSTOM, "");

        boolean hasDiabetes = healthPrefs.getBoolean(KEY_HEALTH_DIABETES, false);
        boolean hasHypertension = healthPrefs.getBoolean(KEY_HEALTH_HYPERTENSION, false);
        boolean hasThyroidDisorder = healthPrefs.getBoolean(KEY_HEALTH_THYROID, false);
        boolean hasHeartDisease = healthPrefs.getBoolean(KEY_HEALTH_HEART_DISEASE, false);
        boolean hasKidneyIssues = healthPrefs.getBoolean(KEY_HEALTH_KIDNEY_ISSUES, false);
        boolean hasGutIssues = healthPrefs.getBoolean(KEY_HEALTH_GUT_ISSUES, false);
        boolean hasPcos = healthPrefs.getBoolean(KEY_HEALTH_PCOS, false);
        String customHealthCondition = healthPrefs.getString(KEY_HEALTH_CUSTOM_CONDITION, "");

        boolean takesVitamins = medPrefs.getBoolean(KEY_MED_VITAMINS, false);
        boolean takesHormones = medPrefs.getBoolean(KEY_MED_HORMONES, false);
        boolean takesAntibiotics = medPrefs.getBoolean(KEY_MED_ANTIBIOTICS, false);
        boolean takesAnxietyMeds = medPrefs.getBoolean(KEY_MED_ANXIETY_MEDS, false);
        boolean takesNoMeds = medPrefs.getBoolean(KEY_MED_NONE, false);
        String otherMedications = medPrefs.getString(KEY_MED_OTHER_MEDICATION, "");

        boolean doesWalking = activityPrefs.getBoolean(KEY_ACTIVITY_WALKING, false);
        boolean doesRunning = activityPrefs.getBoolean(KEY_ACTIVITY_RUNNING, false);
        boolean doesCycling = activityPrefs.getBoolean(KEY_ACTIVITY_CYCLING, false);
        boolean doesSwimming = activityPrefs.getBoolean(KEY_ACTIVITY_SWIMMING, false);
        boolean doesGym = activityPrefs.getBoolean(KEY_ACTIVITY_GYM, false);
        boolean doesYoga = activityPrefs.getBoolean(KEY_ACTIVITY_YOGA, false);
        boolean doesSports = activityPrefs.getBoolean(KEY_ACTIVITY_SPORTS, false);
        String customActivity = activityPrefs.getString(KEY_ACTIVITY_CUSTOM, "");

        StringBuilder plan = new StringBuilder();
        plan.append("<h2>Your Personalized Wellness Plan</h2>");
        plan.append("<p>Here's a set of guidelines based on your selections. Remember, this is for informational purposes and not a substitute for professional medical or dietetic advice.</p>");

        plan.append("<h3>Main Goal</h3>");
        if (wantsToLoseWeight) {
            plan.append("<p><b>Selected Goal: Lose Weight</b><br/>Focus on a sustainable calorie deficit by prioritizing whole, unprocessed foods. Increase protein and fiber intake (from sources compatible with your diet) to promote satiety. Be mindful of portion sizes and aim for regular physical activity.</p>");
        } else if (wantsToManageCondition) {
            plan.append("<p><b>Selected Goal: Manage a Health Condition</b><br/>Your diet will be tailored to support management of your specific health conditions (detailed below). Consistency and adherence to medical advice are key. Focus on foods that support your specific condition.</p>");
        } else if (wantsToIncreaseEnergy) {
            plan.append("<p><b>Selected Goal: Increase Energy</b><br/>Focus on balanced meals with complex carbohydrates (like whole grains, fruits, vegetables) for sustained energy. Ensure adequate hydration and consider nutrient-dense snacks. Avoid energy crashes from sugary foods and drinks.</p>");
        } else if (wantsHealthyLifestyle) {
            plan.append("<p><b>Selected Goal: Live a Healthy Lifestyle</b><br/>Aim for a balanced and varied diet rich in fruits, vegetables, whole grains, lean proteins (or plant-based alternatives), and healthy fats. Consistency in healthy habits is key for long-term well-being.</p>");
        }

        plan.append("<h3>Dietary Approach</h3>");
        String dietaryPatternSpecifics = "";
        if (isVegan) {
            dietaryPatternSpecifics = "<b>Vegan Diet:</b> All meals will be plant-based. Key protein sources include lentils, beans, chickpeas, tofu, tempeh, seitan, nuts, and seeds. Ensure adequate Vitamin B12, Vitamin D, iron, calcium, iodine, and omega-3s through fortified foods or supplements if necessary.";
        } else if (isEggetarian) {
            dietaryPatternSpecifics = "<b>Eggetarian Diet:</b> Plant-based diet that includes eggs. Eggs are a great source of protein. Ensure variety from other plant-based protein sources too.";
        } else if (isVegetarian) {
            dietaryPatternSpecifics = "<b>Vegetarian Diet:</b> Excludes meat, poultry, and fish. May include dairy and eggs. Focus on diverse plant-based proteins, fruits, vegetables, and whole grains.";
        } else if (isPescatarian) {
            dietaryPatternSpecifics = "<b>Pescatarian Diet:</b> Vegetarian diet that includes fish and seafood. Fish provides excellent omega-3 fatty acids. Balance with plenty of plant-based foods.";
        } else if (isNonVegetarian) {
            StringBuilder meatSpecifics = new StringBuilder();
            if (prefersChicken) meatSpecifics.append("chicken, ");
            if (prefersFishMeat) meatSpecifics.append("fish, ");
            if (prefersBeef) meatSpecifics.append("beef, ");
            if (prefersLamb) meatSpecifics.append("lamb, ");
            if (prefersPork) meatSpecifics.append("pork, ");
            if (prefersTurkey) meatSpecifics.append("turkey, ");
            if (prefersDuck) meatSpecifics.append("duck, ");
            if (!customMeat.isEmpty()) meatSpecifics.append(customMeat).append(", ");
            String preferredMeatsString = meatSpecifics.length() > 2 ? meatSpecifics.substring(0, meatSpecifics.length() - 2) : "various meats";
            dietaryPatternSpecifics = "<b>Omnivorous Diet:</b> Includes a variety of plant and animal-based foods. Focus on lean protein choices. Preferred meats include: " + preferredMeatsString + ".";
        } else {
            dietaryPatternSpecifics = "Your dietary pattern will be guided by your specific food choices, intolerances, and health conditions.";
        }
        plan.append("<p>").append(dietaryPatternSpecifics).append("</p>");
        if (!customFoodPreference.isEmpty()) {
            plan.append("<p><em>Your Custom Food Preference:</em> ").append(customFoodPreference).append("</p>");
        }

        boolean hasListedCondition = hasDiabetes || hasHypertension || hasThyroidDisorder || hasHeartDisease || hasKidneyIssues || hasGutIssues || hasPcos;
        if (hasListedCondition || !customHealthCondition.isEmpty()) {
            plan.append("<h3>Health Condition Management</h3>");
            if (hasDiabetes) {
                plan.append("<p><b>Diabetes:</b> Prioritize low-glycemic index foods (whole grains, legumes, non-starchy vegetables). Monitor carbohydrate intake and distribute it evenly. Limit sugary foods and drinks. Regular meal timing is important.</p>");
            }
            if (hasHypertension) {
                plan.append("<p><b>Hypertension:</b> Reduce sodium intake by limiting processed foods and added salt. Emphasize fruits, vegetables, whole grains, and lean protein (DASH diet principles).</p>");
            }
            if (hasThyroidDisorder) {
                plan.append("<p><b>Thyroid Disorder:</b> Ensure adequate iodine and selenium. Be mindful of goitrogenic foods (e.g., raw cruciferous vegetables) in large quantities if hypothyroid; cooking often reduces their effect. Follow medical advice.</p>");
            }
            if (hasHeartDisease) {
                plan.append("<p><b>Heart Disease:</b> Focus on heart-healthy fats (avocados, nuts, olive oil), soluble fiber (oats, beans), and limit saturated/trans fats and sodium. Include omega-3 rich fish if appropriate for your diet.</p>");
            }
            if (hasKidneyIssues) {
                plan.append("<p><b>Kidney Issues:</b> Dietary needs can vary greatly. It often involves managing protein, phosphorus, potassium, and sodium. **Strictly follow your nephrologist's and dietitian's specific advice.**</p>");
            }
            if (hasGutIssues) {
                plan.append("<p><b>IBS/Gut Issues:</b> Consider a low-FODMAP diet under guidance if appropriate. Identify and avoid trigger foods. Probiotics and fiber may be beneficial for some, but individual responses vary. Consult a gastroenterologist or dietitian.</p>");
            }
            if (hasPcos) {
                plan.append("<p><b>PCOS/PCOD:</b> Focus on a balanced diet with low-GI carbohydrates, lean protein, and healthy fats. Regular meals and managing blood sugar can be beneficial. Weight management, if applicable, is often a key component.</p>");
            }
            if (!customHealthCondition.isEmpty()) {
                plan.append("<p><em>Other Custom Condition: ").append(customHealthCondition).append("</em> - Please consult your doctor for specific dietary recommendations related to this condition.</p>");
            }
        }

        boolean hasListedIntolerance = isGlutenIntolerant || isLactoseIntolerant || hasNutAllergy || isSoyIntolerant || hasEggAllergy || hasShellfishAllergy || hasFishIntolerance || isSesameIntolerant || isMustardIntolerant;
        if (hasListedIntolerance || !customIntolerance.isEmpty()) {
            plan.append("<h3>Food Intolerances/Allergies to Address</h3>");
            if (isGlutenIntolerant) {
                plan.append("<p><b>Gluten-Free:</b> Avoid all foods containing wheat, barley, rye. Choose naturally gluten-free grains like rice, quinoa, corn. Read labels carefully.</p>");
            }
            if (isLactoseIntolerant) {
                plan.append("<p><b>Lactose Intolerance:</b> Avoid or limit dairy. Choose lactose-free versions or plant-based milks (almond, soy, oat).</p>");
            }
            if (hasNutAllergy) {
                plan.append("<p><b>Nut Allergy:</b> Strictly avoid all nuts and nut-containing products. Read labels carefully and be aware of cross-contamination.</p>");
            }
            if (isSoyIntolerant) {
                plan.append("<p><b>Soy Intolerance/Allergy:</b> Avoid soy-based products (tofu, soy milk, edamame). Check labels for soy derivatives.</p>");
            }
            if (hasEggAllergy) {
                plan.append("<p><b>Egg Allergy:</b> Avoid eggs and foods containing egg. Check labels on baked goods, sauces, etc.</p>");
            }
            if (hasShellfishAllergy) {
                plan.append("<p><b>Shellfish Allergy:</b> Strictly avoid all shellfish (shrimp, crab, lobster, etc.). Be cautious of cross-contamination.</p>");
            }
            if (hasFishIntolerance) {
                plan.append("<p><b>Fish Allergy/Intolerance:</b> Strictly avoid fish. Check ingredients like fish sauce or Caesar dressing.</p>");
            }
            if (isSesameIntolerant) {
                plan.append("<p><b>Sesame Intolerance/Allergy:</b> Avoid sesame seeds, tahini, and sesame oil. Check labels, especially on bread and Asian cuisine.</p>");
            }
            if (isMustardIntolerant) {
                plan.append("<p><b>Mustard Intolerance/Allergy:</b> Avoid mustard and mustard seeds. Check labels on sauces, dressings, and processed meats.</p>");
            }
            if (!customIntolerance.isEmpty()) {
                plan.append("<p><em>Other Custom Intolerance: ").append(customIntolerance).append("</em> - Avoid related foods and read labels.</p>");
            }
        }

        plan.append("<h3>Sample Meal Structure Ideas</h3>");
        plan.append("<p>These are general ideas. Portions and specific choices should align with your primary goal, dietary pattern, and restrictions.</p>");
        plan.append("<ul>");
        plan.append("<li><b>Breakfast:</b> Oatmeal with berries & seeds (if no nut/seed allergy), scrambled eggs/tofu (check egg/soy intolerance) with spinach & whole-grain toast (check gluten intolerance), or a smoothie with fruit, greens, and a suitable protein powder.</li>");
        plan.append("<li><b>Lunch:</b> Large salad with mixed greens, various vegetables, lean protein (chicken, fish, beans, lentils, tofu - check preferences/restrictions), and a light vinaigrette. Or, a whole-grain wrap/sandwich with similar fillings (check gluten).</li>");
        plan.append("<li><b>Dinner:</b> Baked or grilled lean protein or plant-based protein, a generous portion of steamed or roasted vegetables, and a serving of complex carbohydrates like quinoa, brown rice, or sweet potato.</li>");
        plan.append("<li><b>Snacks:</b> Fresh fruit, a small portion of nuts/seeds (if no allergy), Greek yogurt (or dairy-free alternative if lactose intolerant/vegan), vegetable sticks with hummus.</li>");
        plan.append("</ul>");

        boolean isActive = doesWalking || doesRunning || doesCycling || doesSwimming || doesGym || doesYoga || doesSports || !customActivity.isEmpty();
        if (isActive) {
            plan.append("<h3>Nutrition & Physical Activity</h3>");
            plan.append("<p>Since you are physically active, ensure adequate hydration, especially during and after workouts. Proper fueling can enhance performance and recovery. Consider complex carbohydrates for energy before workouts and a combination of protein and carbohydrates post-workout to aid muscle repair and replenish glycogen stores. The specific amounts will depend on the intensity and duration of your activities.</p>");
            StringBuilder activitiesList = new StringBuilder("<em>Your activities include: ");
            if(doesWalking) activitiesList.append("Walking, ");
            if(doesRunning) activitiesList.append("Running, ");
            if(doesCycling) activitiesList.append("Cycling, ");
            if(doesSwimming) activitiesList.append("Swimming, ");
            if(doesGym) activitiesList.append("Gym/Weight Training, ");
            if(doesYoga) activitiesList.append("Yoga, ");
            if(doesSports) activitiesList.append("Sports, ");
            if(!customActivity.isEmpty()) activitiesList.append(customActivity).append(", ");
            if(activitiesList.length() > "<em>Your activities include: ".length()){
                plan.append(activitiesList.substring(0, activitiesList.length()-2)).append(".</em></p>");
            } else {
                plan.append("</p>");
            }
        } else {
            plan.append("<h3>Physical Activity</h3><p>Consider incorporating regular physical activity into your routine for overall health benefits. Even light activities like daily walks can make a difference.</p>");
        }

        if (!takesNoMeds && (takesVitamins || takesHormones || takesAntibiotics || takesAnxietyMeds || !otherMedications.isEmpty())) {
            plan.append("<h3>Medication & Diet Notes</h3>");
            if (takesVitamins) {
                plan.append("<p><b>Vitamins:</b> Ensure your vitamin intake complements your diet. Some vitamins are best absorbed with food, or with/without certain minerals. If taking specific high-dose vitamins, discuss with your doctor if any dietary adjustments are needed.</p>");
            }
            if (takesHormones) {
                plan.append("<p><b>Hormones:</b> Certain foods might interact with hormone treatments or levels (e.g., grapefruit, soy for some). Discuss any dietary concerns with your endocrinologist or doctor.</p>");
            }
            if (takesAntibiotics) {
                plan.append("<p><b>Antibiotics:</b> Consider including probiotic-rich foods (yogurt, kefir, sauerkraut, kimchi - choose compatible options) after your course to help restore gut flora. Discuss with your doctor.</p>");
            }
            if (takesAnxietyMeds) {
                plan.append("<p><b>Anxiety Medications:</b> A balanced diet avoiding excessive caffeine and sugar can support well-being. Some find omega-3s and magnesium beneficial. Discuss specific dietary interactions with your doctor.</p>");
            }
            if (!otherMedications.isEmpty()){
                plan.append("<p><em>Other Medications: ").append(otherMedications).append("</em> - Please discuss any potential food-drug interactions with your doctor or pharmacist to ensure safety and efficacy.</p>");
            }
        }

        plan.append("<h3>General Wellness Tips</h3>");
        plan.append("<ul>");
        plan.append("<li><b>Hydration:</b> Drink plenty of water throughout the day.</li>");
        plan.append("<li><b>Mindful Eating:</b> Pay attention to hunger/fullness cues. Eat slowly.</li>");
        plan.append("<li><b>Variety:</b> Aim for a colorful plate with a wide variety of whole foods.</li>");
        plan.append("<li><b>Read Labels:</b> Especially important with intolerances/allergies.</li>");
        plan.append("<li><b>Consistency over Perfection:</b> Focus on making sustainable healthy choices most of the time.</li>");
        plan.append("</ul>");

        plan.append("<br/><br/><p><b><i>Important Disclaimer:</b> This personalized plan is generated based on the information you provided and is intended for general guidance and informational purposes only. It is NOT a substitute for professional medical advice, diagnosis, or treatment from a qualified physician, registered dietitian, or other healthcare provider. Always seek the advice of your physician or other qualified health professionals with any questions you may have regarding a medical condition or before making any changes to your diet, exercise routine, or treatment plan. Never disregard professional medical advice or delay in seeking it because of something you have read in this program.</i></p>");

        return plan.toString();
    }
}
