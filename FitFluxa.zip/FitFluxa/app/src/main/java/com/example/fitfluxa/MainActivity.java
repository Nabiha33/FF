package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;


public class MainActivity extends AppCompatActivity {

    // These will be mapped to existing views in activity_main.xml
    private TextView tvWelcomeMessage; // Was tvWelcomeDashboard, will use R.id.tv1
    private MaterialButton btnActionViewProgram; // Was btnViewMyProgram, will use R.id.btn_continue
    // private MaterialButton btnLogout; // No direct equivalent in activity_main.xml to repurpose easily

    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "dietAppPrefs"; // Consistent name
    public static final String KEY_LOGGED_IN_USER_EMAIL = "logged_in_user_email";
    private static final String KEY_USER_NAME_PREFIX = "user_name_";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Using your existing activity_main.xml (Goal Selection UI)
        setContentView(R.layout.activity_main);

        // --- Repurpose existing views from activity_main.xml ---
        // tv1 is the "Welcome" text in activity_main.xml
        tvWelcomeMessage = findViewById(R.id.tv1);

        // btn_continue is the main "Continue" button in activity_main.xml
        btnActionViewProgram = findViewById(R.id.btn_continue);

        // There isn't a clear existing button for "Logout" in activity_main.xml.
        // For now, logout functionality would need to be triggered differently (e.g., options menu)
        // or you would need to add a dedicated logout button to activity_main.xml.
        // MaterialButton btnLogout = findViewById(R.id.some_other_button_for_logout); // Example if you add one

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Personalize the welcome message using R.id.tv1
        if (tvWelcomeMessage != null) {
            String loggedInUserEmail = sharedPreferences.getString(KEY_LOGGED_IN_USER_EMAIL, null);
            if (loggedInUserEmail != null) {
                String userName = sharedPreferences.getString(KEY_USER_NAME_PREFIX + loggedInUserEmail, "User");
                tvWelcomeMessage.setText("Welcome, " + userName + "!"); // Update text of R.id.tv1
                // You might want to hide or change other texts from the goal selection UI here
                // For example, hide the "What is your primary goal?" text:
                TextView tvGoalTitle = findViewById(R.id.tv_title_goal); // Assuming this ID exists for "What is your primary goal?"
                if (tvGoalTitle != null) {
                    tvGoalTitle.setText("Your Dashboard"); // Or tvGoalTitle.setVisibility(View.GONE);
                }
            } else {
                // This case should ideally not be reached if login flow is correct
                // and MainActivity is only accessed after login.
                tvWelcomeMessage.setText("Welcome to FitFluxa!");
            }
        }


        // Repurpose btn_continue to "View My Program"
        if (btnActionViewProgram != null) {
            btnActionViewProgram.setText("View My Program"); // Change button text
            btnActionViewProgram.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, Customizedprogram.class);
                startActivity(intent);
            });
            // Consider hiding other goal selection buttons if this is now a dashboard
            hideGoalSelectionButtons();
        }

        // If you add a dedicated logout button to activity_main.xml with a specific ID,
        // you can initialize and set its listener here. For example:
        // MaterialButton actualBtnLogout = findViewById(R.id.actual_btn_logout_id_in_xml);
        // if (actualBtnLogout != null) {
        //     actualBtnLogout.setOnClickListener(v -> performLogout());
        // }
    }

    private void hideGoalSelectionButtons() {
        // Hide the specific goal selection buttons if MainActivity is serving as a dashboard
        MaterialButton btnLoseWeight = findViewById(R.id.btn_lose_weight);
        MaterialButton btnManageCondition = findViewById(R.id.btn_manage_condition);
        MaterialButton btnIncreaseEnergy = findViewById(R.id.btn_increase_energy);
        MaterialButton btnHealthyLifestyle = findViewById(R.id.btn_healthy_lifestyle);
        TextView tvInfoGoal = findViewById(R.id.tv_info); // The "You can select multiple options" text

        if (btnLoseWeight != null) btnLoseWeight.setVisibility(View.GONE);
        if (btnManageCondition != null) btnManageCondition.setVisibility(View.GONE);
        if (btnIncreaseEnergy != null) btnIncreaseEnergy.setVisibility(View.GONE);
        if (btnHealthyLifestyle != null) btnHealthyLifestyle.setVisibility(View.GONE);
        if (tvInfoGoal != null) tvInfoGoal.setVisibility(View.GONE);
    }

    private void performLogout() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(KEY_LOGGED_IN_USER_EMAIL);
        editor.apply();

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
        Toast.makeText(MainActivity.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}
