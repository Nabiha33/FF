package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color; // For direct color setting, consider ColorStateLists for better practice
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat; // For getting colors in a compatible way

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class GoalSelectionActivity extends AppCompatActivity {

    private ImageView ivBack;
    private MaterialButton btnLoseWeight, btnManageCondition, btnIncreaseEnergy, btnHealthyLifestyle, btnContinue;

    // Using a list to manage selected goals for SharedPreferences
    private List<String> selectedGoalKeys = new ArrayList<>();

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "GoalPrefs";

    // Keys for SharedPreferences for each goal
    public static final String KEY_GOAL_LOSE_WEIGHT = "goal_lose_weight";
    public static final String KEY_GOAL_MANAGE_CONDITION = "goal_manage_condition";
    public static final String KEY_GOAL_INCREASE_ENERGY = "goal_increase_energy";
    public static final String KEY_GOAL_HEALTHY_LIFESTYLE = "goal_healthy_lifestyle";
    // Key for storing the primary goal if only one is allowed, or a list if multiple
    // For Customizedprogram.java, we assumed a single "user_primary_goal".
    // Let's save all selected goals and Customizedprogram.java can decide how to use them.
    // Alternatively, enforce a single selection or define a primary one.
    // For now, we'll save each goal's state. Customizedprogram.java can check these.


    // Storing the original background tint of the goal buttons to revert
    // This is a simple way; ColorStateLists are better for complex state changes.
    private int originalButtonBackgroundColor;
    private int originalButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // IMPORTANT: Make sure you have a layout file named 'activity_goal_selection.xml'
        // or change R.layout.activity_goal_selection to your actual layout file name.
        // Your original code used R.layout.activity_main, which is likely incorrect for this activity.
        setContentView(R.layout.activity_goal_selection);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Initialize views - Ensure these IDs exist in your activity_goal_selection.xml
        ivBack = findViewById(R.id.iv_back);
        btnLoseWeight = findViewById(R.id.btn_lose_weight);
        btnManageCondition = findViewById(R.id.btn_manage_condition);
        btnIncreaseEnergy = findViewById(R.id.btn_increase_energy);
        btnHealthyLifestyle = findViewById(R.id.btn_healthy_lifestyle);
        btnContinue = findViewById(R.id.btn_continue);

        // Define colors (Consider moving these to colors.xml for better management)
        // Using ContextCompat.getColor for theme compatibility
        // Assuming your activity_goal_selection.xml defines the initial button colors.
        // For this example, let's define some default and selected colors.
        // It's better if your XML sets the initial backgroundTint and textColor.
        // We'll try to get the initial color if possible, otherwise use defaults.

        // These would ideally come from your theme or colors.xml
        // Example: originalButtonBackgroundColor = ContextCompat.getColor(this, R.color.your_original_button_bg_color);
        // For now, using hardcoded examples. The colors in your XML for these buttons will be the source.
        // The updateButtonState will toggle between these and a 'selected' style.

        // Let's assume the buttons are styled in XML initially.
        // We'll define a 'selected' style here.
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.purple_500); // Example: a purple selection color
        selectedButtonTextColor = Color.WHITE;

        // Attempt to get original colors if MaterialButton allows it directly,
        // otherwise, this part needs refinement based on how initial styles are set.
        // For simplicity, we'll assume the XML sets the default non-selected state.
        // The updateButtonState will apply a distinct "selected" visual.

        loadPreferences(); // Load and apply initial selections

        ivBack.setOnClickListener(v -> onBackPressed());

        setupGoalButton(btnLoseWeight, KEY_GOAL_LOSE_WEIGHT);
        setupGoalButton(btnManageCondition, KEY_GOAL_MANAGE_CONDITION);
        setupGoalButton(btnIncreaseEnergy, KEY_GOAL_INCREASE_ENERGY);
        setupGoalButton(btnHealthyLifestyle, KEY_GOAL_HEALTHY_LIFESTYLE);

        btnContinue.setOnClickListener(v -> continueWithSelections());
    }

    private void setupGoalButton(MaterialButton button, String goalKey) {
        // Set initial visual state based on loaded preferences
        updateButtonVisualState(button, sharedPreferences.getBoolean(goalKey, false));

        button.setOnClickListener(v -> {
            boolean isSelected = !sharedPreferences.getBoolean(goalKey, false); // Toggle current state
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(goalKey, isSelected);
            editor.apply(); // Apply immediately to reflect in UI update

            updateButtonVisualState(button, isSelected);
        });
    }


    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (selected) {
            // Apply selected state visuals
            // Example: Change background tint and text color
            button.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.purple_700)); // A darker purple for selection
            button.setTextColor(Color.WHITE);
            // You could also use icons: button.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_check));
        } else {
            // Revert to original/default state visuals (defined in your XML or theme)
            // This assumes your XML has the default background tint.
            // If not, you'd need to store and re-apply the original tint.
            button.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.purple_200)); // A lighter purple for default
            button.setTextColor(ContextCompat.getColor(this, R.color.black)); // Or your default text color
            // button.setIcon(null); // Remove icon if you added one
        }
    }


    private void loadPreferences() {
        // The visual state will be set in setupGoalButton after reading from prefs
        // No explicit loading needed here if setupGoalButton handles it.
        // However, if you need to populate selectedGoalKeys list on load:
        selectedGoalKeys.clear();
        if (sharedPreferences.getBoolean(KEY_GOAL_LOSE_WEIGHT, false)) selectedGoalKeys.add(KEY_GOAL_LOSE_WEIGHT);
        if (sharedPreferences.getBoolean(KEY_GOAL_MANAGE_CONDITION, false)) selectedGoalKeys.add(KEY_GOAL_MANAGE_CONDITION);
        if (sharedPreferences.getBoolean(KEY_GOAL_INCREASE_ENERGY, false)) selectedGoalKeys.add(KEY_GOAL_INCREASE_ENERGY);
        if (sharedPreferences.getBoolean(KEY_GOAL_HEALTHY_LIFESTYLE, false)) selectedGoalKeys.add(KEY_GOAL_HEALTHY_LIFESTYLE);
    }

    private void continueWithSelections() {
        // Reload the selectedGoalKeys based on current SharedPreferences state
        loadPreferences(); // Ensure selectedGoalKeys list is up-to-date

        if (selectedGoalKeys.isEmpty()) {
            Toast.makeText(this, "Please select at least one goal.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Preferences are already saved by the button clicks.
        // Now, navigate to the next activity.
        // Your original code passed a string of goals. Customizedprogram.java will now read from SharedPreferences.
        Intent intent = new Intent(this, Intolerence.class); // As per your original flow
        // No need to pass intent extras for goals if Customizedprogram.java reads from SharedPreferences.
        startActivity(intent);
    }
}
