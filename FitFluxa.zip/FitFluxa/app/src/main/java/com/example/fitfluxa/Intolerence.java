package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.ImageView;
// Removed: import android.widget.Toast; // Not used in this version unless you add it back
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
// Removed: import com.google.android.material.textfield.TextInputLayout; // Not directly used as a variable

public class Intolerence extends AppCompatActivity {

    // UI Elements - Changed CheckBoxes to MaterialButtons
    private MaterialButton btnGluten, btnLactose, btnNuts, btnSoy,
            btnEggs, btnShellfish, btnFishIntolerance, btnSesame, btnMustard;
    private TextInputEditText etCustomIntolerance; // Correct type
    private MaterialButton btnNextIntolerance;
    private ImageView ivBack;

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "IntolerancePrefs";

    // Keys for SharedPreferences
    private static final String KEY_GLUTEN = "gluten";
    private static final String KEY_LACTOSE = "lactose";
    private static final String KEY_NUTS = "nuts";
    private static final String KEY_SOY = "soy";
    private static final String KEY_EGGS = "eggs";
    private static final String KEY_SHELLFISH = "shellfish";
    private static final String KEY_FISH_INTOLERANCE = "fish_intolerance";
    private static final String KEY_SESAME = "sesame";
    private static final String KEY_MUSTARD = "mustard";
    private static final String KEY_CUSTOM_INTOLERANCE = "custom_intolerance";

    // Colors for button states
    private int defaultButtonBackgroundColor;
    private int defaultButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure this layout matches the XML in Canvas ID: activity_intolerance_xml_stage2
        setContentView(R.layout.activity_intolerence);

        // Initialize colors (ensure these R.color values exist in your colors.xml)
        defaultButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color);
        defaultButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color);
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color_selected);
        selectedButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color_selected);

        // Initialize UI Elements using NEW IDs
        ivBack = findViewById(R.id.iv_back);

        btnGluten = findViewById(R.id.btn_gluten);
        btnLactose = findViewById(R.id.btn_lactose);
        btnNuts = findViewById(R.id.btn_nuts);
        btnSoy = findViewById(R.id.btn_soy);
        btnEggs = findViewById(R.id.btn_eggs);
        btnShellfish = findViewById(R.id.btn_shellfish);
        btnFishIntolerance = findViewById(R.id.btn_fish_intolerance);
        btnSesame = findViewById(R.id.btn_sesame);
        btnMustard = findViewById(R.id.btn_mustard);

        etCustomIntolerance = findViewById(R.id.et_custom_intolerance); // Correct ID for TextInputEditText
        btnNextIntolerance = findViewById(R.id.btn_next_intolerance); // Correct ID for Next button

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Setup listeners for each intolerance button
        setupIntoleranceButton(btnGluten, KEY_GLUTEN);
        setupIntoleranceButton(btnLactose, KEY_LACTOSE);
        setupIntoleranceButton(btnNuts, KEY_NUTS);
        setupIntoleranceButton(btnSoy, KEY_SOY);
        setupIntoleranceButton(btnEggs, KEY_EGGS);
        setupIntoleranceButton(btnShellfish, KEY_SHELLFISH);
        setupIntoleranceButton(btnFishIntolerance, KEY_FISH_INTOLERANCE);
        setupIntoleranceButton(btnSesame, KEY_SESAME);
        setupIntoleranceButton(btnMustard, KEY_MUSTARD);

        loadPreferences();

        if (ivBack != null) {
            ivBack.setOnClickListener(v -> onBackPressed());
        }

        if (btnNextIntolerance != null) {
            btnNextIntolerance.setOnClickListener(v -> {
                saveCustomTextPreference();
                Intent intent = new Intent(Intolerence.this, Physicalactivities.class);
                startActivity(intent);
            });
        }
    }

    private void setupIntoleranceButton(MaterialButton button, String prefKey) {
        if (button == null) return;
        updateButtonVisualState(button, sharedPreferences.getBoolean(prefKey, false));
        button.setOnClickListener(v -> {
            boolean isSelected = !sharedPreferences.getBoolean(prefKey, false);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(prefKey, isSelected);
            editor.apply();
            updateButtonVisualState(button, isSelected);
        });
    }

    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (button == null) return;
        if (selected) {
            button.setBackgroundTintList(ColorStateList.valueOf(selectedButtonBackgroundColor));
            button.setTextColor(selectedButtonTextColor);
        } else {
            button.setBackgroundTintList(ColorStateList.valueOf(defaultButtonBackgroundColor));
            button.setTextColor(defaultButtonTextColor);
        }
    }

    private void saveCustomTextPreference() {
        if (etCustomIntolerance == null) return;
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_CUSTOM_INTOLERANCE, etCustomIntolerance.getText().toString().trim());
        editor.apply();
    }

    private void loadPreferences() {
        updateButtonVisualState(btnGluten, sharedPreferences.getBoolean(KEY_GLUTEN, false));
        updateButtonVisualState(btnLactose, sharedPreferences.getBoolean(KEY_LACTOSE, false));
        updateButtonVisualState(btnNuts, sharedPreferences.getBoolean(KEY_NUTS, false));
        updateButtonVisualState(btnSoy, sharedPreferences.getBoolean(KEY_SOY, false));
        updateButtonVisualState(btnEggs, sharedPreferences.getBoolean(KEY_EGGS, false));
        updateButtonVisualState(btnShellfish, sharedPreferences.getBoolean(KEY_SHELLFISH, false));
        updateButtonVisualState(btnFishIntolerance, sharedPreferences.getBoolean(KEY_FISH_INTOLERANCE, false));
        updateButtonVisualState(btnSesame, sharedPreferences.getBoolean(KEY_SESAME, false));
        updateButtonVisualState(btnMustard, sharedPreferences.getBoolean(KEY_MUSTARD, false));

        if (etCustomIntolerance != null) {
            etCustomIntolerance.setText(sharedPreferences.getString(KEY_CUSTOM_INTOLERANCE, ""));
        }
    }
}
