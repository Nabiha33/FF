package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText; // Retained for et_other_medication if it's TextInputEditText
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;

public class Medications extends AppCompatActivity {

    // UI Elements - Changed CheckBoxes to MaterialButtons
    private MaterialButton btnVitamins, btnHormones, btnAntibiotics,
            btnAnxietyMeds, btnNoneMeds;
    private TextInputEditText etOtherMedication; // Updated type
    private TextInputLayout tilOtherMedication; // To enable/disable
    private MaterialButton btnNextMedications;
    private ImageView ivBack;

    private List<MaterialButton> medicationOptionButtons; // For easier management

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "MedPrefs";

    // Keys for SharedPreferences (ensure these match what Customizedprogram.java expects)
    private static final String KEY_VITAMINS = "vitamins";
    private static final String KEY_HORMONES = "hormones";
    private static final String KEY_ANTIBIOTICS = "antibiotics";
    private static final String KEY_ANXIETY_MEDS = "anxiety_meds";
    private static final String KEY_NONE = "none"; // For the "None" option itself
    private static final String KEY_OTHER_MEDICATION = "other_medication";

    // Colors for button states
    private int defaultButtonBackgroundColor;
    private int defaultButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medications); // Should match the XML ID: activity_medications_xml_stage2

        // Initialize colors
        defaultButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color);
        defaultButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color);
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color_selected);
        selectedButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color_selected);

        // Initialize UI Elements
        ivBack = findViewById(R.id.iv_back);
        btnVitamins = findViewById(R.id.btn_vitamins);
        btnHormones = findViewById(R.id.btn_hormones);
        btnAntibiotics = findViewById(R.id.btn_antibiotics);
        btnAnxietyMeds = findViewById(R.id.btn_anxiety_meds);
        btnNoneMeds = findViewById(R.id.btn_none_meds);

        tilOtherMedication = findViewById(R.id.til_other_medication);
        etOtherMedication = findViewById(R.id.et_other_medication);
        btnNextMedications = findViewById(R.id.btn_next_medications);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Group medication option buttons for easier handling
        medicationOptionButtons = new ArrayList<>();
        medicationOptionButtons.add(btnVitamins);
        medicationOptionButtons.add(btnHormones);
        medicationOptionButtons.add(btnAntibiotics);
        medicationOptionButtons.add(btnAnxietyMeds);

        // Setup listeners
        setupMedicationButton(btnVitamins, KEY_VITAMINS);
        setupMedicationButton(btnHormones, KEY_HORMONES);
        setupMedicationButton(btnAntibiotics, KEY_ANTIBIOTICS);
        setupMedicationButton(btnAnxietyMeds, KEY_ANXIETY_MEDS);
        setupNoneButton(); // Special setup for the "None" button

        loadPreferences(); // Load initial states

        ivBack.setOnClickListener(v -> onBackPressed());

        btnNextMedications.setOnClickListener(v -> {
            saveOtherMedicationPreference(); // Ensure custom text is saved
            Intent intent = new Intent(Medications.this, Customizedprogram.class);
            startActivity(intent);
        });
    }

    private void setupMedicationButton(MaterialButton button, String prefKey) {
        // Set initial visual state from SharedPreferences
        updateButtonVisualState(button, sharedPreferences.getBoolean(prefKey, false));

        button.setOnClickListener(v -> {
            boolean isCurrentlySelected = sharedPreferences.getBoolean(prefKey, false);
            boolean newSelectedState = !isCurrentlySelected;

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(prefKey, newSelectedState);

            if (newSelectedState) {
                // If this button is selected, "None" must be deselected
                editor.putBoolean(KEY_NONE, false);
                updateButtonVisualState(btnNoneMeds, false); // Visually deselect "None"
                setOtherMedInputsEnabled(true); // Enable other inputs
            }
            editor.apply();
            updateButtonVisualState(button, newSelectedState);
        });
    }

    private void setupNoneButton() {
        // Set initial visual state for "None" button
        updateButtonVisualState(btnNoneMeds, sharedPreferences.getBoolean(KEY_NONE, false));

        btnNoneMeds.setOnClickListener(v -> {
            boolean isCurrentlySelected = sharedPreferences.getBoolean(KEY_NONE, false);
            boolean newSelectedState = !isCurrentlySelected;

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(KEY_NONE, newSelectedState);

            if (newSelectedState) {
                // If "None" is selected, deselect all other medication buttons
                for (MaterialButton medButton : medicationOptionButtons) {
                    // Get the key associated with each button to update SharedPreferences
                    String key = getPrefKeyForButton(medButton);
                    if (key != null) {
                        editor.putBoolean(key, false);
                    }
                    updateButtonVisualState(medButton, false); // Visually deselect
                }
                etOtherMedication.setText(""); // Clear custom text
                editor.putString(KEY_OTHER_MEDICATION, ""); // Save cleared custom text
                setOtherMedInputsEnabled(false); // Disable other inputs
            } else {
                // If "None" is deselected, re-enable other inputs
                setOtherMedInputsEnabled(true);
            }
            editor.apply();
            updateButtonVisualState(btnNoneMeds, newSelectedState);
        });
    }

    private String getPrefKeyForButton(MaterialButton button) {
        if (button.getId() == R.id.btn_vitamins) return KEY_VITAMINS;
        if (button.getId() == R.id.btn_hormones) return KEY_HORMONES;
        if (button.getId() == R.id.btn_antibiotics) return KEY_ANTIBIOTICS;
        if (button.getId() == R.id.btn_anxiety_meds) return KEY_ANXIETY_MEDS;
        return null;
    }


    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (selected) {
            button.setBackgroundTintList(ColorStateList.valueOf(selectedButtonBackgroundColor));
            button.setTextColor(selectedButtonTextColor);
        } else {
            button.setBackgroundTintList(ColorStateList.valueOf(defaultButtonBackgroundColor));
            button.setTextColor(defaultButtonTextColor);
        }
    }

    private void setOtherMedInputsEnabled(boolean enabled) {
        for (MaterialButton medButton : medicationOptionButtons) {
            medButton.setEnabled(enabled);
            if(!enabled && !sharedPreferences.getBoolean(KEY_NONE, false)){
                // If disabling but "None" isn't the cause (e.g. future logic), keep visual state
            } else if (!enabled) {
                updateButtonVisualState(medButton, false); // Reset visual state if disabling due to "None"
            }
        }
        tilOtherMedication.setEnabled(enabled);
        etOtherMedication.setEnabled(enabled);
        if (!enabled) {
            etOtherMedication.setText(""); // Clear text when disabling
        }
    }

    private void saveOtherMedicationPreference() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (btnNoneMeds.isSelected() || !etOtherMedication.isEnabled()) { // If "None" is selected or field is disabled
            editor.putString(KEY_OTHER_MEDICATION, "");
        } else {
            editor.putString(KEY_OTHER_MEDICATION, etOtherMedication.getText().toString().trim());
        }
        editor.apply();
    }

    private void loadPreferences() {
        // Load and apply visual state for all medication buttons
        for (MaterialButton medButton : medicationOptionButtons) {
            String key = getPrefKeyForButton(medButton);
            if (key != null) {
                updateButtonVisualState(medButton, sharedPreferences.getBoolean(key, false));
            }
        }
        // Load and apply visual state for "None" button
        updateButtonVisualState(btnNoneMeds, sharedPreferences.getBoolean(KEY_NONE, false));

        // Load custom medication text
        etOtherMedication.setText(sharedPreferences.getString(KEY_OTHER_MEDICATION, ""));

        // Set initial enabled state of other inputs based on "None" selection
        if (sharedPreferences.getBoolean(KEY_NONE, false)) {
            setOtherMedInputsEnabled(false);
        } else {
            setOtherMedInputsEnabled(true);
        }
    }
}
