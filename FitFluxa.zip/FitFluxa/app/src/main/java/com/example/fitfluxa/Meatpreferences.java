package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class Meatpreferences extends AppCompatActivity {

    // UI Elements - Changed CheckBoxes to MaterialButtons
    private MaterialButton btnChicken, btnFishMeat, btnBeef,
            btnLamb, btnPork, btnTurkey, btnDuck;
    private TextInputEditText etCustomMeat; // Changed from EditText
    private MaterialButton btnNextMeatPreferences; // Changed ID and type
    private ImageView ivBack;

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "MeatPrefs"; // Consistent

    // Keys for SharedPreferences (ensure these match what Customizedprogram.java expects)
    private static final String KEY_CHICKEN = "chicken";
    private static final String KEY_FISH_MEAT = "fish_meat"; // Updated to match button ID logic
    private static final String KEY_BEEF = "beef";
    private static final String KEY_LAMB = "lamb";
    private static final String KEY_PORK = "pork";
    private static final String KEY_TURKEY = "turkey";
    private static final String KEY_DUCK = "duck";
    private static final String KEY_CUSTOM_MEAT = "custom_meat";

    // Colors for button states
    private int defaultButtonBackgroundColor;
    private int defaultButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // XML is activity_meatpreferences_xml_stage2 (ID of the immersive in Canvas)
        setContentView(R.layout.activity_meatpreferences);

        // Initialize colors
        defaultButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color);
        defaultButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color);
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color_selected);
        selectedButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color_selected);

        // Initialize UI Elements
        ivBack = findViewById(R.id.iv_back);

        btnChicken = findViewById(R.id.btn_chicken);
        btnFishMeat = findViewById(R.id.btn_fish_meat); // Updated ID
        btnBeef = findViewById(R.id.btn_beef);
        btnLamb = findViewById(R.id.btn_lamb);
        btnPork = findViewById(R.id.btn_pork);
        btnTurkey = findViewById(R.id.btn_turkey);
        btnDuck = findViewById(R.id.btn_duck);

        etCustomMeat = findViewById(R.id.et_custom_meat); // Inside TextInputLayout
        btnNextMeatPreferences = findViewById(R.id.btn_next_meat_preferences);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Setup listeners for each meat preference button
        setupMeatButton(btnChicken, KEY_CHICKEN);
        setupMeatButton(btnFishMeat, KEY_FISH_MEAT);
        setupMeatButton(btnBeef, KEY_BEEF);
        setupMeatButton(btnLamb, KEY_LAMB);
        setupMeatButton(btnPork, KEY_PORK);
        setupMeatButton(btnTurkey, KEY_TURKEY);
        setupMeatButton(btnDuck, KEY_DUCK);

        loadPreferences(); // Load initial states for buttons and custom text

        if (ivBack != null) {
            ivBack.setOnClickListener(v -> onBackPressed());
        }

        btnNextMeatPreferences.setOnClickListener(v -> {
            saveCustomTextPreference(); // Save custom text
            // Navigate to the next activity in your flow
            // Your original code navigated to Medications.class
            Intent intent = new Intent(Meatpreferences.this, Medications.class);
            startActivity(intent);
        });
    }

    private void setupMeatButton(MaterialButton button, String prefKey) {
        // Set initial visual state from SharedPreferences
        updateButtonVisualState(button, sharedPreferences.getBoolean(prefKey, false));

        button.setOnClickListener(v -> {
            boolean isSelected = !sharedPreferences.getBoolean(prefKey, false); // Toggle current state
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(prefKey, isSelected);
            editor.apply(); // Save change immediately

            updateButtonVisualState(button, isSelected);
        });
    }

    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (selected) {
            button.setBackgroundTintList(ColorStateList.valueOf(selectedButtonBackgroundColor));
            button.setTextColor(selectedButtonTextColor);
        } else {
            button.setBackgroundTintList(ColorStateList.valueOf(defaultButtonBackgroundColor));
            button.setTextColor(defaultButtonTextColor);
        }
    }

    private void saveCustomTextPreference() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_CUSTOM_MEAT, etCustomMeat.getText().toString().trim());
        editor.apply();
    }

    private void loadPreferences() {
        // Set initial visual state for all buttons
        updateButtonVisualState(btnChicken, sharedPreferences.getBoolean(KEY_CHICKEN, false));
        updateButtonVisualState(btnFishMeat, sharedPreferences.getBoolean(KEY_FISH_MEAT, false));
        updateButtonVisualState(btnBeef, sharedPreferences.getBoolean(KEY_BEEF, false));
        updateButtonVisualState(btnLamb, sharedPreferences.getBoolean(KEY_LAMB, false));
        updateButtonVisualState(btnPork, sharedPreferences.getBoolean(KEY_PORK, false));
        updateButtonVisualState(btnTurkey, sharedPreferences.getBoolean(KEY_TURKEY, false));
        updateButtonVisualState(btnDuck, sharedPreferences.getBoolean(KEY_DUCK, false));

        // Load custom meat text
        etCustomMeat.setText(sharedPreferences.getString(KEY_CUSTOM_MEAT, ""));
    }
}
