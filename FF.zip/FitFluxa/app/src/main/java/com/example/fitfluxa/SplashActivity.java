package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper; // It's good practice to use Looper.getMainLooper() for UI-related posts

import androidx.appcompat.app.AppCompatActivity; // Changed from android.app.Activity

// Ensure LoginActivity is correctly imported if it's in the same package or specify full path
// import com.example.fitfluxa.LoginActivity; // This was in your original, ensure it's correct

public class SplashActivity extends AppCompatActivity { // Changed to AppCompatActivity

    private static final int SPLASH_DISPLAY_LENGTH = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure you have a layout file named activity_splash.xml
        // and that it contains the ImageView with id splash_logo
        setContentView(R.layout.activity_splash);

        // Using Handler(Looper.getMainLooper()) is a more robust way to post to the main thread
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start next activity
                // Ensure LoginActivity is the correct activity to start after splash
                Intent mainIntent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(mainIntent);
                finish(); // close splash so user can't go back to it
            }
        }, SPLASH_DISPLAY_LENGTH);
    }
}
