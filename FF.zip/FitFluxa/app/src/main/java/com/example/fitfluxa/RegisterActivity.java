package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView; // For the back button
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPassword, etConfirmPassword;
    private Button btnRegister; // In your XML, this is a MaterialButton
    private ImageView ivBack; // Back button

    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "dietAppPrefs";
    // Using prefixes for user-specific data keyed by email
    private static final String KEY_USER_NAME_PREFIX = "user_name_";
    private static final String KEY_USER_PASSWORD_HASH_PREFIX = "user_password_hash_";

    // WARNING: STATIC SALT IS NOT SECURE FOR PRODUCTION.
    // Each user should have a unique, randomly generated salt.
    private static final String STATIC_SALT = "FitFluxaSuperSecretSalt!@#$"; // CHANGE THIS!

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up); // Ensure this layout file is correct

        // Initialize views
        ivBack = findViewById(R.id.iv_back);
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register); // Ensure this is a MaterialButton in XML if you want Material styling

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        ivBack.setOnClickListener(v -> {
            onBackPressed(); // Standard back functionality
        });

        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim().toLowerCase(); // Standardize email
            String password = etPassword.getText().toString();
            String confirmPassword = etConfirmPassword.getText().toString();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) ||
                    TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError("Enter a valid email address");
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                return;
            } else {
                etEmail.setError(null); // Clear error
            }

            if (password.length() < 6) {
                etPassword.setError("Password must be at least 6 characters");
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                return;
            } else {
                etPassword.setError(null);
            }

            if (!password.equals(confirmPassword)) {
                etConfirmPassword.setError("Passwords do not match");
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            } else {
                etConfirmPassword.setError(null);
            }

            // Check if user (email) already exists
            if (sharedPreferences.contains(KEY_USER_PASSWORD_HASH_PREFIX + email)) {
                Toast.makeText(this, "An account with this email already exists.", Toast.LENGTH_LONG).show();
                return;
            }

            String hashedPassword = hashPassword(password, STATIC_SALT);
            if (hashedPassword == null) {
                Toast.makeText(this, "Error creating account. Could not process password.", Toast.LENGTH_LONG).show();
                return;
            }

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(KEY_USER_NAME_PREFIX + email, name);
            editor.putString(KEY_USER_PASSWORD_HASH_PREFIX + email, hashedPassword); // Store HASHED password
            editor.apply();

            Toast.makeText(this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            // Clear previous activities from the stack so user can't go back to register after success
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Hashes a password using SHA-256 with a static salt.
     * WARNING: This is a basic example for demonstration.
     * For production, use a stronger algorithm (Argon2, scrypt, bcrypt)
     * and a unique, randomly generated salt per user, stored alongside the hash.
     */
    public static String hashPassword(String password, String salt) {
        if (password == null || salt == null) return null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String saltedPassword = salt + password;
            byte[] hashedBytes = digest.digest(saltedPassword.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder(2 * hashedBytes.length);
            for (byte b : hashedBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e("RegisterActivity", "Error hashing password: SHA-256 algorithm not found.", e);
            return null;
        }
    }
}
