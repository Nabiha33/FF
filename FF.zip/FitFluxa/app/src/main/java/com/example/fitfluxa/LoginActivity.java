package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

// Assuming RegisterActivity.hashPassword is accessible if in the same package
// or you might need to make it public static in RegisterActivity or move to a utility class.
// For this example, we'll call RegisterActivity.hashPassword directly.

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private Button btnLogin, btnRegister; // These are MaterialButtons in your XML
    private TextView tvForgotPassword;

    private SharedPreferences sharedPreferences;
    // Consistent SharedPreferences name and key prefixes with RegisterActivity
    private static final String SHARED_PREF_NAME = "dietAppPrefs";
    private static final String KEY_USER_NAME_PREFIX = "user_name_"; // To retrieve username if needed
    private static final String KEY_USER_PASSWORD_HASH_PREFIX = "user_password_hash_";

    // WARNING: STATIC SALT IS NOT SECURE FOR PRODUCTION.
    // This MUST match the salt used in RegisterActivity.
    private static final String STATIC_SALT = "FitFluxaSuperSecretSalt!@#$"; // Ensure this is IDENTICAL to the one in RegisterActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Ensure this layout file is correct

        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        btnRegister = findViewById(R.id.btn_register);
        tvForgotPassword = findViewById(R.id.tv_forgot_password);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim().toLowerCase(); // Standardize email
            String password = etPassword.getText().toString();

            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                Toast.makeText(LoginActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError("Enter a valid email address");
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                return;
            } else {
                etEmail.setError(null);
            }

            // Retrieve the stored HASHED password for the given email
            String storedPasswordHash = sharedPreferences.getString(KEY_USER_PASSWORD_HASH_PREFIX + email, null);

            if (storedPasswordHash == null) {
                // User not found
                Toast.makeText(LoginActivity.this, "Invalid email or password.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Hash the entered password using the SAME salt and method as during registration
            String enteredPasswordHash = RegisterActivity.hashPassword(password, STATIC_SALT);

            if (enteredPasswordHash != null && enteredPasswordHash.equals(storedPasswordHash)) {
                // Login successful
                String userName = sharedPreferences.getString(KEY_USER_NAME_PREFIX + email, "User"); // Get username
                Toast.makeText(LoginActivity.this, "Login successful! Welcome " + userName, Toast.LENGTH_SHORT).show();

                // Navigate to the main part of your app (e.g., MainActivity or GoalSelectionActivity)
                // Your original LoginActivity navigated to NextActivity.class.
                // Let's assume after login, user goes to GoalSelectionActivity if it's part of onboarding
                // or MainActivity if onboarding is done.
                // For now, let's go to GoalSelectionActivity as per your general flow.
                Intent intent = new Intent(LoginActivity.this, GoalSelectionActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            } else {
                // Invalid credentials
                Toast.makeText(LoginActivity.this, "Invalid email or password.", Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(v -> {
            // Navigate to RegisterActivity
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        tvForgotPassword.setOnClickListener(v -> {
            // Secure password recovery is complex (e.g., email link, security questions).
            // Simply showing the password (even if it was plain text) is insecure.
            // Since we store a hash, we cannot retrieve the original password.
            Toast.makeText(LoginActivity.this, "Password recovery feature not implemented.", Toast.LENGTH_LONG).show();
            // Optionally, you could navigate to a dedicated "Forgot Password" screen
            // Intent intent = new Intent(LoginActivity.this, Forgotpassword.class); // Your Forgotpassword.xml exists
            // startActivity(intent);
        });
    }
}
