package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
// No need for TextInputLayout variable if only controlling TextInputEditText directly for text.

public class Physicalactivities extends AppCompatActivity {

    // UI Elements - Changed CheckBoxes to MaterialButtons
    private MaterialButton btnWalking, btnRunning, btnCycling,
            btnSwimming, btnGym, btnYoga, btnSports;
    private TextInputEditText etCustomActivity; // Changed from EditText
    private MaterialButton btnNextPhysicalActivities; // Changed ID and type
    private ImageView ivBack;

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "ActivityPrefs"; // Consistent

    // Keys for SharedPreferences (ensure these match what Customizedprogram.java expects)
    private static final String KEY_WALKING = "walking";
    private static final String KEY_RUNNING = "running";
    private static final String KEY_CYCLING = "cycling";
    private static final String KEY_SWIMMING = "swimming";
    private static final String KEY_GYM = "gym";
    private static final String KEY_YOGA = "yoga";
    private static final String KEY_SPORTS = "sports";
    private static final String KEY_CUSTOM_ACTIVITY = "custom_activity";

    // Colors for button states
    private int defaultButtonBackgroundColor;
    private int defaultButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // XML is activity_physicalactivities_xml_stage2 (ID of the immersive in Canvas)
        setContentView(R.layout.activity_physicalactivities);

        // Initialize colors
        defaultButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color);
        defaultButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color);
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color_selected);
        selectedButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color_selected);

        // Initialize UI Elements
        ivBack = findViewById(R.id.iv_back);

        btnWalking = findViewById(R.id.btn_walking);
        btnRunning = findViewById(R.id.btn_running);
        btnCycling = findViewById(R.id.btn_cycling);
        btnSwimming = findViewById(R.id.btn_swimming);
        btnGym = findViewById(R.id.btn_gym);
        btnYoga = findViewById(R.id.btn_yoga);
        btnSports = findViewById(R.id.btn_sports);

        etCustomActivity = findViewById(R.id.et_custom_activity); // Inside TextInputLayout
        btnNextPhysicalActivities = findViewById(R.id.btn_next_physical_activities);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Setup listeners for each activity button
        setupActivityButton(btnWalking, KEY_WALKING);
        setupActivityButton(btnRunning, KEY_RUNNING);
        setupActivityButton(btnCycling, KEY_CYCLING);
        setupActivityButton(btnSwimming, KEY_SWIMMING);
        setupActivityButton(btnGym, KEY_GYM);
        setupActivityButton(btnYoga, KEY_YOGA);
        setupActivityButton(btnSports, KEY_SPORTS);

        loadPreferences(); // Load initial states for buttons and custom text

        ivBack.setOnClickListener(v -> onBackPressed());

        btnNextPhysicalActivities.setOnClickListener(v -> {
            saveCustomTextPreference(); // Save custom text
            Intent intent = new Intent(Physicalactivities.this, Diseases.class); // As per your original flow
            startActivity(intent);
        });
    }

    private void setupActivityButton(MaterialButton button, String prefKey) {
        // Set initial visual state from SharedPreferences
        updateButtonVisualState(button, sharedPreferences.getBoolean(prefKey, false));

        button.setOnClickListener(v -> {
            boolean isSelected = !sharedPreferences.getBoolean(prefKey, false); // Toggle current state
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(prefKey, isSelected);
            editor.apply(); // Save change immediately

            updateButtonVisualState(button, isSelected);
        });
    }

    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (selected) {
            button.setBackgroundTintList(ColorStateList.valueOf(selectedButtonBackgroundColor));
            button.setTextColor(selectedButtonTextColor);
        } else {
            button.setBackgroundTintList(ColorStateList.valueOf(defaultButtonBackgroundColor));
            button.setTextColor(defaultButtonTextColor);
        }
    }

    private void saveCustomTextPreference() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_CUSTOM_ACTIVITY, etCustomActivity.getText().toString().trim());
        editor.apply();
    }

    private void loadPreferences() {
        // Set initial visual state for all buttons
        updateButtonVisualState(btnWalking, sharedPreferences.getBoolean(KEY_WALKING, false));
        updateButtonVisualState(btnRunning, sharedPreferences.getBoolean(KEY_RUNNING, false));
        updateButtonVisualState(btnCycling, sharedPreferences.getBoolean(KEY_CYCLING, false));
        updateButtonVisualState(btnSwimming, sharedPreferences.getBoolean(KEY_SWIMMING, false));
        updateButtonVisualState(btnGym, sharedPreferences.getBoolean(KEY_GYM, false));
        updateButtonVisualState(btnYoga, sharedPreferences.getBoolean(KEY_YOGA, false));
        updateButtonVisualState(btnSports, sharedPreferences.getBoolean(KEY_SPORTS, false));

        // Load custom activity text
        etCustomActivity.setText(sharedPreferences.getString(KEY_CUSTOM_ACTIVITY, ""));
    }
}
