package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Foodpreferences extends AppCompatActivity {

    // UI Elements - Changed CheckBoxes to MaterialButtons
    private MaterialButton btnVegetarian, btnNonVegetarian, btnVegan,
            btnEggetarian, btnPescatarian;
    private TextInputEditText etCustomFood; // Correct type
    private MaterialButton btnNextFoodPreferences; // Correct ID and type
    private ImageView ivBack;

    // For managing mutually exclusive buttons
    private List<MaterialButton> allDietButtons;

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "FoodPrefs"; // Consistent

    // Keys for SharedPreferences (ensure these match what Customizedprogram.java expects)
    private static final String KEY_VEGETARIAN = "vegetarian";
    private static final String KEY_NON_VEGETARIAN = "nonVegetarian";
    private static final String KEY_VEGAN = "vegan";
    private static final String KEY_EGGETARIAN = "eggetarian";
    private static final String KEY_PESCATARIAN = "pescatarian";
    private static final String KEY_CUSTOM_FOOD = "customFood";

    // Colors for button states
    private int defaultButtonBackgroundColor;
    private int defaultButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure this layout matches the XML in Canvas ID: activity_foodpreferences_xml_stage2
        setContentView(R.layout.activity_foodpreferences);

        // Initialize colors (ensure these R.color values exist in your colors.xml)
        defaultButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color);
        defaultButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color);
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color_selected);
        selectedButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color_selected);

        // Initialize UI Elements using NEW IDs
        ivBack = findViewById(R.id.iv_back);

        btnVegetarian = findViewById(R.id.btn_vegetarian);
        btnNonVegetarian = findViewById(R.id.btn_non_vegetarian);
        btnVegan = findViewById(R.id.btn_vegan);
        btnEggetarian = findViewById(R.id.btn_eggetarian);
        btnPescatarian = findViewById(R.id.btn_pescatarian);

        etCustomFood = findViewById(R.id.et_custom_food); // Correct ID for TextInputEditText
        btnNextFoodPreferences = findViewById(R.id.btn_next_food_preferences); // Correct ID for Next button

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        allDietButtons = new ArrayList<>(Arrays.asList(btnVegetarian, btnNonVegetarian, btnVegan, btnEggetarian, btnPescatarian));

        // Setup listeners for each food preference button
        setupFoodButton(btnVegetarian, KEY_VEGETARIAN);
        setupFoodButton(btnNonVegetarian, KEY_NON_VEGETARIAN);
        setupFoodButton(btnVegan, KEY_VEGAN);
        setupFoodButton(btnEggetarian, KEY_EGGETARIAN);
        setupFoodButton(btnPescatarian, KEY_PESCATARIAN);

        loadPreferences(); // Load initial states for buttons and custom text

        if (ivBack != null) {
            ivBack.setOnClickListener(v -> onBackPressed());
        }

        if (btnNextFoodPreferences != null) {
            btnNextFoodPreferences.setOnClickListener(v -> {
                saveCustomTextPreference(); // Save custom text
                Intent intent = new Intent(Foodpreferences.this, Meatpreferences.class);
                startActivity(intent);
            });
        }
    }

    private void setupFoodButton(MaterialButton button, String prefKey) {
        if (button == null) return;
        updateButtonVisualState(button, sharedPreferences.getBoolean(prefKey, false));

        button.setOnClickListener(v -> {
            boolean isCurrentlySelected = sharedPreferences.getBoolean(prefKey, false);
            boolean newSelectedState = !isCurrentlySelected;

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(prefKey, newSelectedState);

            // Handle mutual exclusivity:
            if (newSelectedState) { // If the current button is being selected
                if (prefKey.equals(KEY_VEGAN)) {
                    deselectIncompatibleButtons(editor, Arrays.asList(KEY_NON_VEGETARIAN, KEY_VEGETARIAN, KEY_EGGETARIAN, KEY_PESCATARIAN));
                } else if (prefKey.equals(KEY_NON_VEGETARIAN)) {
                    deselectIncompatibleButtons(editor, Arrays.asList(KEY_VEGAN, KEY_VEGETARIAN, KEY_EGGETARIAN, KEY_PESCATARIAN));
                } else if (prefKey.equals(KEY_VEGETARIAN)) {
                    deselectIncompatibleButtons(editor, Arrays.asList(KEY_NON_VEGETARIAN, KEY_VEGAN));
                    // Eggetarian & Pescatarian can stay if Vegetarian is selected,
                    // but if user selects Vegetarian, we might not want to automatically deselect them
                    // unless they were the *only* other option selected. This logic can be refined.
                } else if (prefKey.equals(KEY_EGGETARIAN) || prefKey.equals(KEY_PESCATARIAN)) {
                    // If Eggetarian or Pescatarian is selected, deselect Non-Vegetarian and Vegan
                    deselectIncompatibleButtons(editor, Arrays.asList(KEY_NON_VEGETARIAN, KEY_VEGAN));
                }
            }
            editor.apply(); // Save all changes from this click event

            loadButtonStatesAndUpdateVisuals(); // Update all button visuals to reflect the new state
        });
    }

    private void deselectIncompatibleButtons(SharedPreferences.Editor editor, List<String> incompatibleKeys) {
        for (String key : incompatibleKeys) {
            editor.putBoolean(key, false); // Set the preference to false
        }
    }

    // Helper method to map a button to its SharedPreferences key
    private String getPrefKeyForButton(MaterialButton button) {
        if (button == null) return null;
        int id = button.getId();
        if (id == R.id.btn_vegetarian) return KEY_VEGETARIAN;
        if (id == R.id.btn_non_vegetarian) return KEY_NON_VEGETARIAN;
        if (id == R.id.btn_vegan) return KEY_VEGAN;
        if (id == R.id.btn_eggetarian) return KEY_EGGETARIAN;
        if (id == R.id.btn_pescatarian) return KEY_PESCATARIAN;
        return null;
    }

    private void loadButtonStatesAndUpdateVisuals() {
        for (MaterialButton button : allDietButtons) {
            if (button != null) {
                String key = getPrefKeyForButton(button);
                if (key != null) {
                    updateButtonVisualState(button, sharedPreferences.getBoolean(key, false));
                }
            }
        }
    }

    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (button == null) return;
        if (selected) {
            button.setBackgroundTintList(ColorStateList.valueOf(selectedButtonBackgroundColor));
            button.setTextColor(selectedButtonTextColor);
        } else {
            button.setBackgroundTintList(ColorStateList.valueOf(defaultButtonBackgroundColor));
            button.setTextColor(defaultButtonTextColor);
        }
    }

    private void saveCustomTextPreference() {
        if (etCustomFood == null) return;
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_CUSTOM_FOOD, etCustomFood.getText().toString().trim());
        editor.apply();
    }

    private void loadPreferences() {
        loadButtonStatesAndUpdateVisuals(); // This will set the visual state for all buttons
        if (etCustomFood != null) {
            etCustomFood.setText(sharedPreferences.getString(KEY_CUSTOM_FOOD, ""));
        }
    }
}
