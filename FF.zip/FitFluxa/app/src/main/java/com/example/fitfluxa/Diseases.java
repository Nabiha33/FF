package com.example.fitfluxa; // Ensure this matches your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
// No need for TextInputLayout variable if only controlling TextInputEditText directly for text.

public class Diseases extends AppCompatActivity {

    // UI Elements - Changed CheckBoxes to MaterialButtons
    private MaterialButton btnDiabetes, btnHypertension, btnThyroid,
            btnHeartDisease, btnKidneyIssues, btnGutIssues, btnPcos;
    private TextInputEditText etCustomCondition; // Changed from EditText
    private MaterialButton btnNextDiseases; // Changed ID and type
    private ImageView ivBack;

    // SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "HealthPrefs"; // Consistent

    // Keys for SharedPreferences (ensure these match what Customizedprogram.java expects)
    private static final String KEY_DIABETES = "diabetes";
    private static final String KEY_HYPERTENSION = "hypertension";
    private static final String KEY_THYROID = "thyroid";
    private static final String KEY_HEART_DISEASE = "heart_disease";
    private static final String KEY_KIDNEY_ISSUES = "kidney_issues";
    private static final String KEY_GUT_ISSUES = "gut_issues";
    private static final String KEY_PCOS = "pcos";
    private static final String KEY_CUSTOM_CONDITION = "custom_condition";

    // Colors for button states
    private int defaultButtonBackgroundColor;
    private int defaultButtonTextColor;
    private int selectedButtonBackgroundColor;
    private int selectedButtonTextColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // XML is activity_diseases_xml_stage2 (ID of the immersive in Canvas)
        setContentView(R.layout.activity_diseases);

        // Initialize colors
        defaultButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color);
        defaultButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color);
        selectedButtonBackgroundColor = ContextCompat.getColor(this, R.color.button_option_bg_color_selected);
        selectedButtonTextColor = ContextCompat.getColor(this, R.color.button_option_text_color_selected);

        // Initialize UI Elements
        ivBack = findViewById(R.id.iv_back);

        btnDiabetes = findViewById(R.id.btn_diabetes);
        btnHypertension = findViewById(R.id.btn_hypertension);
        btnThyroid = findViewById(R.id.btn_thyroid);
        btnHeartDisease = findViewById(R.id.btn_heart_disease);
        btnKidneyIssues = findViewById(R.id.btn_kidney_issues);
        btnGutIssues = findViewById(R.id.btn_gut_issues);
        btnPcos = findViewById(R.id.btn_pcos);

        etCustomCondition = findViewById(R.id.et_custom_condition); // Inside TextInputLayout
        btnNextDiseases = findViewById(R.id.btn_next_diseases);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Setup listeners for each disease button
        setupDiseaseButton(btnDiabetes, KEY_DIABETES);
        setupDiseaseButton(btnHypertension, KEY_HYPERTENSION);
        setupDiseaseButton(btnThyroid, KEY_THYROID);
        setupDiseaseButton(btnHeartDisease, KEY_HEART_DISEASE);
        setupDiseaseButton(btnKidneyIssues, KEY_KIDNEY_ISSUES);
        setupDiseaseButton(btnGutIssues, KEY_GUT_ISSUES);
        setupDiseaseButton(btnPcos, KEY_PCOS);

        loadPreferences(); // Load initial states for buttons and custom text

        ivBack.setOnClickListener(v -> onBackPressed());

        btnNextDiseases.setOnClickListener(v -> {
            saveCustomTextPreference(); // Save custom text
            Intent intent = new Intent(Diseases.this, Foodpreferences.class);
            startActivity(intent);
        });
    }

    private void setupDiseaseButton(MaterialButton button, String prefKey) {
        // Set initial visual state from SharedPreferences
        updateButtonVisualState(button, sharedPreferences.getBoolean(prefKey, false));

        button.setOnClickListener(v -> {
            boolean isSelected = !sharedPreferences.getBoolean(prefKey, false); // Toggle current state
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(prefKey, isSelected);
            editor.apply(); // Save change immediately

            updateButtonVisualState(button, isSelected);
        });
    }

    private void updateButtonVisualState(MaterialButton button, boolean selected) {
        if (selected) {
            button.setBackgroundTintList(ColorStateList.valueOf(selectedButtonBackgroundColor));
            button.setTextColor(selectedButtonTextColor);
        } else {
            button.setBackgroundTintList(ColorStateList.valueOf(defaultButtonBackgroundColor));
            button.setTextColor(defaultButtonTextColor);
        }
    }

    private void saveCustomTextPreference() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_CUSTOM_CONDITION, etCustomCondition.getText().toString().trim());
        editor.apply();
    }

    private void loadPreferences() {
        // Set initial visual state for all buttons
        updateButtonVisualState(btnDiabetes, sharedPreferences.getBoolean(KEY_DIABETES, false));
        updateButtonVisualState(btnHypertension, sharedPreferences.getBoolean(KEY_HYPERTENSION, false));
        updateButtonVisualState(btnThyroid, sharedPreferences.getBoolean(KEY_THYROID, false));
        updateButtonVisualState(btnHeartDisease, sharedPreferences.getBoolean(KEY_HEART_DISEASE, false));
        updateButtonVisualState(btnKidneyIssues, sharedPreferences.getBoolean(KEY_KIDNEY_ISSUES, false));
        updateButtonVisualState(btnGutIssues, sharedPreferences.getBoolean(KEY_GUT_ISSUES, false));
        updateButtonVisualState(btnPcos, sharedPreferences.getBoolean(KEY_PCOS, false));

        // Load custom condition text
        etCustomCondition.setText(sharedPreferences.getString(KEY_CUSTOM_CONDITION, ""));
    }
}
